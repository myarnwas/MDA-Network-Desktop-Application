class Message:
    def __init__(self, content: str, message_type: str = "real"):
        self.content = content
        self.type = message_type

    def encrypt(self):
        print(f"Encrypting message content: {self.content}")
        return f"encrypted({self.content})"

    def decrypt(self, key: str):
        print(f"Decrypting message with key: {key}")
        return f"decrypted({self.content})"
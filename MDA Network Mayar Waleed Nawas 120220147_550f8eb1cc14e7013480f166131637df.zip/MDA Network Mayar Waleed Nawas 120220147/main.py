from system import System
from node import Node
from network import Network
from message import Message

# إنشاء كائن من System
system = System()

# الانضمام إلى شبكة
system.join_network("Network_Mayar")

# إنشاء شبكة جديدة
system.create_network("New_Network_Nawas")

# إنشاء عقدة وإضافتها إلى شبكة
node1 = Node("First")
network = Network("Test_My_Network")
network.add_node(node1)

# إرسال رسالة
node1.send_message("Hi,This is Mayar Real Network!")

# تشفير وفك تشفير رسالة
message = Message("Welcome,This is Mayar NOT Real Network(Secure World!)! ")
encrypted_message = message.encrypt()
print(encrypted_message)

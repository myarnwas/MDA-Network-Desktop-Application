class DHT:
    def __init__(self):
        self.node_info = {}

    def store_node_info(self, node):
        print(f"Storing node info for {node.id}")
        self.node_info[node.id] = node

    def fetch_node_info(self, node_id: str):
        print(f"Fetching info for node {node_id}")
        return self.node_info.get(node_id, None)

    def update_node_list(self):
        print("Updating the list of nodes in the DHT.")
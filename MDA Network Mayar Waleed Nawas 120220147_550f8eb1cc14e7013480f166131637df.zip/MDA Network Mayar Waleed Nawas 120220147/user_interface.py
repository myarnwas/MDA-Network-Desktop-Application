# إزالة: from system import System
class UserInterface:
    def __init__(self, system):
        self.system = system

    def display_messages(self):
        print("Displaying messages to the user.")

    def send_message(self, message: str):
        encrypted_message = self.system.encrypt_message(message)
        print(f"Sending encrypted message: {encrypted_message}")

    def manage_networks(self):
        print("Managing networks through the user interface.")

class Network:
    def __init__(self, name: str):
        self.name = name
        self.nodes = []

    def add_node(self, node):
        print(f"Adding node {node.id} to the network {self.name}")
        self.nodes.append(node)

    def remove_node(self, node):
        print(f"Removing node {node.id} from the network {self.name}")
        self.nodes.remove(node)

    def route_message(self, message: str):
        print(f"Routing message through the network {self.name}: {message}")
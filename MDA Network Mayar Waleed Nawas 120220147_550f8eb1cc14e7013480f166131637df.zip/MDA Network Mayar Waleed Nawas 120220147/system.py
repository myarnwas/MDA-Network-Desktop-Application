
from dht import DHT
from user_interface import UserInterface
from network import Network


class System:
    def __init__(self):
        self.nodes = []
        self.networks = []
        self.dht = DHT()
        self.ui = UserInterface(self)

    def join_network(self, configuration: str):
        print(f"Joining network with configuration: {configuration}")
        self.dht.update_node_list()
        network = Network(configuration)
        self.networks.append(network)

    def create_network(self, config_file: str):
        print(f"Creating a new network with configuration: {config_file}")
        new_network = Network(config_file)
        self.networks.append(new_network)

    def manage_nodes(self):
        print("Managing nodes in the network.")

    def encrypt_message(self, message: str) -> str:
        print(f"Encrypting message: {message}")
        return f"encrypted({message})"

    def decrypt_message(self, encrypted_message: str) -> str:
        print(f"Decrypting message: {encrypted_message}")
        return f"decrypted({encrypted_message})"
    


class Node:
    def __init__(self, node_id: str, status: str = "active"):
        self.id = node_id
        self.status = status

    def send_message(self, message: str):
        print(f"Node {self.id} sending message: {message}")

    def receive_message(self):
        print(f"Node {self.id} received a message.")